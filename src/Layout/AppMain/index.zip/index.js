import {BrowserRouter as Router, Route, Redirect} from 'react-router-dom';
import React, {Suspense, lazy, Fragment} from 'react';
import {
    ToastContainer,
} from 'react-toastify';
const Dashboard = lazy(() 	=> import('../../Pages/Dashboard'));
const Login = lazy(() 		=> import('../../Pages/Login'));
const Signup = lazy(() 		=> import('../../Pages/Signup'));
const ForegetPassword = lazy(() 	=> import('../../Pages/ForegetPassword'));
const Elements = lazy(() 	=> import('../../Pages/Elements/'));

const AppMain = () => {
    const ServerPath = '64.202.185.51:4000';
    if(ServerPath){
		localStorage.setItem('ServerPath', JSON.stringify(ServerPath));
    }
    return (
        <Fragment>
            {/* Elements */}
            <Suspense fallback={
                <div className="loader-container">
                    <div className="loader-container-inner">
                        <h6 className="mt-3">
                            Please wait.
                            <small></small>
                        </h6>
                    </div>
                </div>
            }>
            <Route path="/elements" component={Elements}/>
            </Suspense>

            {/* Login */}

            <Suspense fallback={
                <div className="loader-container">
                    <div className="loader-container-inner">
                        <h6 className="mt-3">
                            Please wait.
                            <small></small>
                        </h6>
                    </div>
                </div>
                
            }>
                <Route path="/login" component={Login}/>
            </Suspense>
            <Route exact path="/" render={() => (
                <Redirect to="/login/loginuser"/>
            )}/>
			
			 {/* Register */}

            <Suspense fallback={
                <div className="loader-container">
                    <div className="loader-container-inner">
                        <h6 className="mt-3">
                            Please wait.
                            <small></small>
                        </h6>
                    </div>
                </div>
            }>
                <Route path="/Signup" component={Signup}/>
            </Suspense>
			
			{/* Forget Password */}

            <Suspense fallback={
                <div className="loader-container">
                    <div className="loader-container-inner">
                        <h6 className="mt-3">
                            Please wait.
                            <small></small>
                        </h6>
                    </div>
                </div>
            }>
                <Route path="/ForegetPassword" component={ForegetPassword}/>
            </Suspense>
			
			{/* Dashboard */}

            <Suspense fallback={
                <div className="loader-container">
                    <div className="loader-container-inner">
                        <h6 className="mt-3">
                            Please wait.
                            <small></small>
                        </h6>
                    </div>
                </div>
            }>
            <Route path="/Dashboard" component={Dashboard}/>
            </Suspense>
            <ToastContainer/>
        </Fragment>
    )
};
export default AppMain;