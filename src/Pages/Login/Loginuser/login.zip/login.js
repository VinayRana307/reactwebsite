import React, { Component } from "react";
import { Row, FormGroup, Button, HelpBlock } from 'react-bootstrap';
import { Label, } from 'reactstrap';
import { isEmail, isEmpty, isLength, isContainWhiteSpace } from 'shared/validator';
import MetisMenu from 'react-metismenu';
import twitter from './twitter.png';
import facebook from './facebook.png';
import google from './google.png';
import home from './login_gif.gif';
class Login extends Component {
	constructor(props) {
		super(props);
		const ServerPath = JSON.parse(localStorage.getItem('ServerPath'));
		this.state = {
			ServerPath: ServerPath,
			formData: {}, // Contains login form data
			errors: {}, // Contains login field errors
			formSubmitted: false, // Indicates submit status of login form
			loading: false, // Indicates in progress state of login form
			email: '',
			password: '',
		}
	}
	handleInputChange = (event) => {
		const target = event.target;
		const value = target.value;
		const name = target.name;
		let { formData } = this.state;
		formData[name] = value;
		this.setState({
			formData: formData
		});
	}
	validateLoginForm = (e) => {
		let errors = {};
		const { formData } = this.state;
		if (isEmpty(formData.email)) {
			errors.email = "Email can't be blank";
		} else if (!isEmail(formData.email)) {
			errors.email = "Please enter a valid email";
		}
		if (isEmpty(formData.password)) {
			errors.password = "Password can't be blank";
		} else if (isContainWhiteSpace(formData.password)) {
			errors.password = "Password should not contain white spaces";
		} else if (!isLength(formData.password, { gte: 6, lte: 16, trim: true })) {
			errors.password = "Password's length must between 6 to 16";
		}
		if (isEmpty(errors)) {
			return true;
		} else {
			return errors;
		}
	}
	login = (event) => {
		event.preventDefault();
		let errors = this.validateLoginForm();
		if (errors === true) {
			const formData = this.state.formData;
			const requestOptions = {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					wstoken: 'any_token',
					wsfunction: 'any_function',
					moodlewsrestformat: 'json',
					email: formData.email,
					password: formData.password,
				})
			};
			return fetch('http://'+this.state.ServerPath+'/api/login', requestOptions)
				.then(handleResponse)
				.then(res => {
					//const aa = this.setToken(res.token)  //setting the token in local storage
					//return Promise.resolve(res);
					if (res) {
						//res.authdata = window.btoa(email + ':' + password);
						localStorage.setItem('res', JSON.stringify(res));
					}
					return res;
				});
			function handleResponse(response) {
				return response.text().then(text => {
					const data = text && JSON.parse(text);
					if (response.ok) {
						if (response.status === 200) {
							window.location.href = "#/dashboard/streetnest";
						}
					}
					else {
						if (response.status === 401) {
							// auto logout if 401 response returned from api
						} else if (response.status === 400) {
							alert('Please enter correct email/password.');
							(response.statusText);
							//errors.email = "asd";
						}
						const error = (data && data.message) || response.statusText;
					}
					return data;
				});
			}
		} else {
			this.setState({
				errors: errors,
				formSubmitted: true,
			});
		}
	}
	render() {
		const { errors, formSubmitted } = this.state;
		return (
			<div className="container-fluid">
				<div className="row">
					<div className="col-sm-6 side1">
						<span><img src={home} width={400} height={400} /></span>
					</div>
					<div className="col-sm-6 side2">
						<div className="row">
							<div className="col-md-2">

							</div>
							<div className="col-md-9 loginpage">
								<div className="row">
									<div className="col-sm-12 text-center head">
										<p>SIGN IN</p>
									</div>
								</div>
								<div className="row text">
									<div className="col-sm-12 text-center">
										<p style={{ marginTop: "-9px" }}>with your social network</p>
									</div>
								</div>
								<div className="row links col-sm-12">
									<div className="col-md-4 text-right">
										<a href="https://www.google.com" id="google"> <img src={google} width={17} height={17} alt="google" /> GOOGLE</a>
									</div>
									<div className="col-md-4 text-center">
										<a href="https://www.facebook.com" id="facebook"><img src={facebook} width={22} height={20} alt="facebook" /> FACEBOOK</a>
									</div>
									<div className="col-md-4">
										<a href="https://www.twitter.com" id="twitter"><img src={twitter} width={22} height={27} alt="twitter" /> TWITTER</a>
									</div>
								</div>
								<div className="row">
									<div className="col-sm-12 hline">
										<p>or</p>
									</div>
								</div>
								<div className="row">
									<div className="col-sm-12">
										<div className="Login">
											<form onSubmit={this.login}>
												<FormGroup className="text-center">
													<Label className="col-md-12 pad0" validationstate={formSubmitted ? (errors.email ? 'error' : 'success') : null}>
														<input type="text" name="email" placeholder="Username or Email" onChange={this.handleInputChange} name="email" />
														{errors.email &&
															<HelpBlock>{errors.email}</HelpBlock>
														}
													</Label>
												</FormGroup>
												<FormGroup className="text-center">
													<Label className="col-md-12 pad0" validationstate={formSubmitted ? (errors.password ? 'error' : 'success') : null}>
														<input type="password" name="password" placeholder="Password" onChange={this.handleInputChange} name="password" />
														{errors.password &&
															<HelpBlock>{errors.password}</HelpBlock>
														}
													</Label>
												</FormGroup>
												<Button type="submit" className="border_radius0" id="button">SIGN IN</Button>
												<span id="signup">Not a member?</span>
												<span><MetisMenu content={RegisterUser} activeLinkFromLocation className="vertical-nav-menu display_inlineblock registeruser" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down" /></span>
												<span id=""><MetisMenu content={ForegetPassword} activeLinkFromLocation className="vertical-nav-menu display_inlineblock registeruser" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down" /></span>
											</form>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div className="col-md-1">
						</div>
					</div>
				</div>
			</div>
		)
	}
}
export const RegisterUser = [
	{
		label: 'Sign up',
		to: '#/signup/registeruser',
	},
];
export const ForegetPassword = [
	{
		label: 'Forgot Password',
		to: '#/foregetpassword/resetpassword',
	},
];
export default Login;