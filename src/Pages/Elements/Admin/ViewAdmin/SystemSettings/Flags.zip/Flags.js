import React, {Component, Fragment} from 'react';
import {Button} from 'reactstrap';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import {Row,Col,Card,CardBody,Form,FormGroup,Label,Input} from 'reactstrap';
class ViewFlags extends Component {
	constructor(props){
		super(props);
		const ServerPath = JSON.parse(localStorage.getItem('ServerPath'));
		this.state = {
			ServerPath: ServerPath,
			formData:{},values:'',
		}
	}
	handleInputChange = (event) => {
        const target = event.target;
		const value = target.type === 'checkbox' ? target.checked : target.value;
		const name = target.name;
		
        let { formData } = this.state;
		formData[name] = value;
        this.setState({
            formData: formData,
		});
	}
	handleSubmit = (event) => {
		if(this.state.formData === true){
			this.setState({checkBox:'1'}) 
		}else{
			
		}
        event.preventDefault();
			const formData = this.state.formData;
			const ww = localStorage.getItem('res');
			const myObject = JSON.parse(ww);
			const token = myObject.body.token;
				const requestOptions = {
				method: 'PUT',
				headers: { 
					'Authorization':'Bearer'+' '+ token,
					'Content-Type': 'application/json',
					'Accept':'application/json',
				},
				body: JSON.stringify({
					wstoken: 'jwtToken',
					wsfunction: 'any_function',
					moodlewsrestformat: 'json',
					id :'',
					EFT : formData.EFT,
					chequePrinting: formData.chequePrinting,
					SupposeTax: formData.SupposeTax,
					ClientIncomeBankSummary: formData.ClientIncomeBankSummary,
					ExpenseCredit: formData.ExpenseCredit,
					TenantPayments : formData.TenantPayments,
					ResidentLettings : formData.ResidentLettings,
					standardLetters : formData.standardLetters,
					RemittanceAdvice: formData.RemittanceAdvice,
					supplierAutomaticPayment : formData.supplierAutomaticPayment,
					SupplierPartialPayments: formData.SupplierPartialPayments,
					backupOutlook : formData.backupOutlook,
					ClientPropertyTenantSupplierId: formData.ClientPropertyTenantSupplierId,
					maintenancePlanFailure : formData.maintenancePlanFailure,
					propertyAvailableFunds: formData.propertyAvailableFunds,
					negativeAvailableFunds : formData.negativeAvailableFunds,
					previousBalance : formData.previousBalance,
					FormColours: formData.FormColours,
					commercialManagement: formData.commercialManagement,
					SuppressBankDetails : formData.SuppressBankDetails,
					SuppressTenantDemands: formData.SuppressTenantDemands,
					SuppressInterestArrears : formData.SuppressInterestArrears,
					SuppressStatementSumms : formData.SuppressStatementSumms,
					reportThroughViewer: formData.reportThroughViewer,
					gasSafetyRemainderBlankDates : formData.gasSafetyRemainderBlankDates,
					gasSafetyRemainder : formData.gasSafetyRemainder,
					TaxMessageLogEntry : formData.TaxMessageLogEntry,
					emailLogEntry : formData.emailLogEntry,
					BatchEFTPayments: formData.BatchEFTPayments,
					clientsDetailsRepairOrder: formData.clientsDetailsRepairOrder,
					HorizontalScrollBars: formData.HorizontalScrollBars,
					uncompletedRepairOrders: formData.uncompletedRepairOrders,

				})
				};
				return fetch('http://'+this.state.ServerPath+'/api/updateSyatemTableList',requestOptions)
				.then(handleResponse)
				.then(res => {
				});
				function handleResponse(response) {
				return response.text().then(text => {
					const data = text && JSON.parse(text);
					if (response.ok) {
						if(response.status === 200){
							window.location.reload();
						}
					}
					else{
						if (response.status === 401) {
							// auto logout if 401 response returned from api
						}else if(response.status === 400){
							(response.statusText);
							//errors.email = "asd";
						}
						const error = (data && data.message) || response.statusText;
					}
					return data;
				});
			}
	} 
    render() {
        return (
            <Fragment>
                <ReactCSSTransitionGroup
                    component="div"
                    transitionName="TabsAnimation"
                    transitionAppear={true}
                    transitionAppearTimeout={0}
                    transitionEnter={false}
                    transitionLeave={false}>
                     <Row>
                        <Col className="pad0">
							<Card className="main-card mb-3 pb-4">
								<CardBody className="pad0 min-vh-100">
									<Form className="col-md-12">
										<div className="card-header mt-3 ">Flags</div>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" value="1" name="EFT" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Enable EFT</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="chequePrinting" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Enable cheque Printing</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="SupposeTax" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Suppose Tax</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="ClientIncomeBankSummary" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Client Income on Bank summary</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="ExpenseCredit" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Expense credit on bank summary</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="TenantPayments" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Tenant Payments on bank summary</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="ResidentLettings" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Resident Lettings Database</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="standardLetters" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Save merged standard letters</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="RemittanceAdvice" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Save Remittance advice note as PDF</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="supplierAutomaticPayment" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Enable supplier automatic payment</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="SupplierPartialPayments" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Allow Supplier partial payments</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="backupOutlook" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Send backup via Outlook</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="ClientPropertyTenantSupplierId" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Show new client property/Property/Tenant & Supplier ID's</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="maintenancePlanFailure" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Do not Check for maintenance plan failure </Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="propertyAvailableFunds" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Show property available funds</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="negativeAvailableFunds" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Show negative available funds</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="previousBalance" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Print balance of previous debits/credits on Tenant Demands </Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="FormColours" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Enable Form colours</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="commercialManagement" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Enable commercial management</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="SuppressBankDetails" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Suppress Bank Details </Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="SuppressTenantDemands" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Suppress tenant demands</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="SuppressInterestArrears" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Suppress interest on arrears</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="SuppressStatementSumms" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Suppress statement summs on prop </Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="reportThroughViewer" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Print report through viewer</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="gasSafetyRemainderBlankDates" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Add gas safety remainder for 'blank' dates</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="gasSafetyRemainder" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Add gas safety remainder </Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="TaxMessageLogEntry" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Ask about tax message log entry </Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="emailLogEntry" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Ask about email log entry</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="BatchEFTPayments" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Batch EFT Payments </Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="clientsDetailsRepairOrder" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Print clients details on Repair Order</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12">
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="HorizontalScrollBars" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Hide Horizontal scroll bars</Label>
											</Label>
											<Label className="col-md-4"> 
												<Label className="pad0"><Input type="checkbox" name="uncompletedRepairOrders" checked={this.state.isChecked} onChange={this.handleInputChange}/>  Check for uncompleted repair orders</Label>
											</Label>
										</FormGroup>
										<FormGroup className="col-md-12 mt-4 pad0">
											<Label className="col-md-12 text-center">
												<Button className="button" type="submit">Ok</Button>
												<Button className="button" type="button">Cancel</Button>
											</Label>
										</FormGroup>
									</Form>	
								</CardBody>
							</Card>
                        </Col>
                    </Row>
                </ReactCSSTransitionGroup>
            </Fragment>
        );
    }
};
export default ViewFlags;