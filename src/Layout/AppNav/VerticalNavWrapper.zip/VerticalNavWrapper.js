import React, {Component, Fragment} from 'react';
import {withRouter} from 'react-router-dom';
import MetisMenu from 'react-metismenu';
import {ClientList, ComponentsNav, FormsNav, WidgetsNav, ChartsNav, PropertyNav,TanentNav,SupplierNav,ChargesNav,BankNav,AuditNav,AdminNav,ReportsNav,StandardLetterNav} from './NavItems';
import UserProfile from '../../assets/utils/images/avatars/user_profile.png';
import { Link } from 'react-router-dom'
import {FontAwesomeIcon} from '@fortawesome/react-fontawesome';
import {faPencilAlt} from '@fortawesome/free-solid-svg-icons';

class Nav extends Component {
constructor(props){
	super(props);
    this.state = {
		data: null,
		  Pic:'',
		 selectFiles:null,
	};
}
componentDidMount() {
	var ww = localStorage.getItem('res');
	var myObject = JSON.parse(ww);
	var token = myObject.body.token;
    fetch('http://64.202.185.51:4000/api/getMyProfile', {
      method: 'GET',
      headers: {
			'Authorization':'Bearer'+' '+ token,
			//"Content-Type": "multipart/form-data",
			"Content-Type": "application/json",
			//"Accept": "application/json",
		},
    })
    .then((response) => {
      return response.json();
    })
    .then((data) => {
		this.setState({
			Pic:data.body.usersDetail.profileImage,
			Data:data.body
		})
    })
}
		  UploadImage = () => {
			const file = event.target.files[0]
			console.log(file)
				  const url = 'http://64.202.185.51:4000/api/updateProfileImage';
    		const formData = new FormData();
			formData.append('file',file)
			var ww = localStorage.getItem('res');
			var myObject = JSON.parse(ww);
			var token = myObject.body.token;
			const requestOptions = {
				method: 'POST', 	
				headers: {
					'content-type': 'multipart/form-data',
					'Authorization':'Bearer'+' '+ token,
				},
				body: JSON.stringify({
					wstoken: 'jwtToken',
					wsfunction: 'any_function',
					moodlewsrestformat: 'json',
					image : file.name,
				})
			};console.log(requestOptions)
			return fetch('http://64.202.185.51:4000/api/updateProfileImage',requestOptions)
			.then(handleResponse)
			.then(res => {
			});
			function handleResponse(response) {
			return response.text().then(text => {
				const data = text && JSON.parse(text);
				if (response.ok) {
					if(response.status === 200){
						alert('Image Upload Successfully')
						//window.location.href = "#/elements/clients-list";
					}
				}
				else{
					if (response.status === 401) {
						// auto logout if 401 response returned from api
					}else if(response.status === 400){
						(response.statusText);
						//errors.email = "asd";
					}
					const error = (data && data.message) || response.statusText;
				}
				return data;
			});
			}
		};
    render() {
		var {Data}= this.state;
		var pic ='http://64.202.185.51:4000/'+this.state.Pic;
		console.log(this.state.Pic)
		const imagestyle={
			width: '130px',
			borderRadius:' 50%',
			height: '106px',
		}
        return (
            <Fragment>
			<div className="text-center user_profilesection">
				 <h4>
				 
					 <img src={pic} className="Userimage"/></h4>
					 <input type="file" name="file-input" onChange={this.UploadImage}  id="image"
                   accept="image/jpg, image/jpeg"/>
				 <Link to="/elements/editprofile" title="Edit Your Profile"><p></p>
				 </Link>
				</div>
					<MetisMenu content={ClientList} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={PropertyNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={TanentNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={SupplierNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={ChargesNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={BankNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={AuditNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={AdminNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={ReportsNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
					<MetisMenu content={StandardLetterNav} activeLinkFromLocation className="vertical-nav-menu" iconNamePrefix="" classNameStateIcon="pe-7s-angle-down"/>
            </Fragment>
        );
    }
    isPathActive(path) {
        return this.props.location.pathname.startsWith(path);
		console.log(path);
    }
}
export default withRouter(Nav);